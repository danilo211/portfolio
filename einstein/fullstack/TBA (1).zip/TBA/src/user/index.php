<?php
header('Location: login.php'); // Redireciona para a página de login
exit;
?>
