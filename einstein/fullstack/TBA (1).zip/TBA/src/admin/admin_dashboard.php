<?php
session_start();
include '../config/database.php';

if (!isset($_SESSION['admin'])) {
    header('Location: admin_login.php');
    exit;
}

// Lógica para gerenciar torneios e participantes
$query = "SELECT * FROM tournaments";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Painel do Administrador</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>Painel do Administrador</h1>
    <p>Bem-vindo, <?php echo $_SESSION['admin']; ?>!</p>
    <h2>Gerenciar Torneios</h2>
    <table>
        <tr>
            <th>ID</th>
            <th>Nome</th>
            <th>Data</th>
            <th>Ações</th>
        </tr>
        <?php while ($tournament = $result->fetch_assoc()): ?>
            <tr>
                <td><?php echo $tournament['id']; ?></td>
                <td><?php echo $tournament['name']; ?></td>
                <td><?php echo $tournament['date']; ?></td>
                <td>
                    <a href="manage_tournaments.php?id=<?php echo $tournament['id']; ?>">Gerenciar</a>
                </td>
            </tr>
        <?php endwhile; ?>
    </table>
</body>
</html>
