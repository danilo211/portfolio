<?php
header('Location: admin_login.php'); // Redireciona para a página de login do administrador
exit;
?>
