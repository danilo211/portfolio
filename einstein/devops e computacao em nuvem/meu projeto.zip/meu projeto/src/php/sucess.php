<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Sucesso</title>
    <link rel="stylesheet" href="style.css"> <!-- Link para o CSS -->
</head>
<body>
    <div class="success-message">
        <h2>Dados salvos com sucesso!</h2>
        <p>Obrigado por enviar suas informações.</p>
        <a href="index.php">Voltar ao Formulário</a>
    </div>
</body>
</html>
